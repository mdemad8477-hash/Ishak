package com.smartplay.app.data

import android.net.Uri

data class Video(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val size: Long,
    val folder: String,
)
