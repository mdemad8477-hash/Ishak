package com.smartplay.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.smartplay.app.data.Video
import com.smartplay.app.data.VideoRepository
import com.smartplay.app.ui.LibraryScreen
import com.smartplay.app.ui.SmartPlayTheme
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SmartPlayTheme { Root() } }
    }
}

@Composable
private fun Root() {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(granted, reload) {
        if (granted) {
            loading = true
            videos = VideoRepository.load(ctx)
            loading = false
        }
    }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Smart Play", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Allow access to your videos so Smart Play can show and play them.",
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 16.dp),
            )
            Button(onClick = { launcher.launch(perm) }) { Text("Allow access") }
        }
    } else {
        LibraryScreen(
            videos = videos,
            loading = loading,
            onRefresh = { reload++ },
            onOpen = { idx, list ->
                // Keep the Intent small: send a window of at most 300 items.
                val start = max(0, idx - 100)
                val sub = list.subList(start, min(list.size, start + 300))
                ctx.startActivity(
                    Intent(ctx, PlayerActivity::class.java).apply {
                        data = list[idx].uri
                        putStringArrayListExtra(
                            PlayerActivity.EXTRA_PLAYLIST,
                            ArrayList(sub.map { it.uri.toString() })
                        )
                        putExtra(PlayerActivity.EXTRA_INDEX, idx - start)
                    }
                )
            },
        )
    }
}
