package com.smartplay.app.data

import android.content.Context

/** Remembers the last playback position of each video. */
class ResumeStore(context: Context) {
    private val prefs = context.getSharedPreferences("resume", Context.MODE_PRIVATE)
    fun get(key: String): Long = prefs.getLong(key, 0L)
    fun put(key: String, positionMs: Long) {
        prefs.edit().putLong(key, positionMs).apply()
    }
}
