package com.smartplay.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF8C75FF),
    secondary = Color(0xFF1FC8E8),
    background = Color(0xFF0B0D17),
    surface = Color(0xFF141726),
    surfaceVariant = Color(0xFF1C2033),
    onBackground = Color(0xFFEDEEF5),
    onSurface = Color(0xFFEDEEF5),
    onSurfaceVariant = Color(0xFFA9ADC4),
)

@Composable
fun SmartPlayTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
