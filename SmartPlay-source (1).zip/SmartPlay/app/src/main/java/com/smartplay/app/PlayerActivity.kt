package com.smartplay.app

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.smartplay.app.data.ResumeStore

class PlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PLAYLIST = "playlist"
        const val EXTRA_INDEX = "index"
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var store: ResumeStore
    private var items: List<Uri> = emptyList()
    private var startIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ResumeStore(this)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
            controllerShowTimeoutMs = 3500
            setShowNextButton(true)
            setShowPreviousButton(true)
        }
        setContentView(playerView)

        if (!parseIntent(intent)) {
            Toast.makeText(this, "No video to play", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (parseIntent(intent) && player != null) {
            saveProgress()
            releasePlayer()
            initPlayer()
        }
    }

    private fun parseIntent(intent: Intent): Boolean {
        val list = intent.getStringArrayListExtra(EXTRA_PLAYLIST)
        items = if (!list.isNullOrEmpty()) list.map { it.toUri() } else listOfNotNull(intent.data)
        startIndex = intent.getIntExtra(EXTRA_INDEX, 0)
        return items.isNotEmpty()
    }

    override fun onStart() {
        super.onStart()
        if (player == null && items.isNotEmpty()) initPlayer()
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        releasePlayer()
    }

    private fun initPlayer() {
        val p = ExoPlayer.Builder(this).build()
        p.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true,
        )
        p.setHandleAudioBecomingNoisy(true)
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Cannot play this video", Toast.LENGTH_SHORT).show()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    p.currentMediaItem?.mediaId?.let { store.put(it, 0L) }
                }
            }
        })

        val mediaItems = items.map {
            MediaItem.Builder().setUri(it).setMediaId(it.toString()).build()
        }
        val idx = startIndex.coerceIn(0, mediaItems.lastIndex)
        p.setMediaItems(mediaItems, idx, store.get(items[idx].toString()))
        p.prepare()
        p.playWhenReady = true

        playerView.player = p
        player = p
    }

    private fun saveProgress() {
        val p = player ?: return
        val item = p.currentMediaItem ?: return
        startIndex = p.currentMediaItemIndex
        val pos = p.currentPosition
        val dur = p.duration
        val finished = dur != C.TIME_UNSET && pos > dur - 5000
        store.put(item.mediaId, if (finished) 0L else pos)
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (_: Exception) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration,
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        playerView.useController = !isInPictureInPictureMode
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}
